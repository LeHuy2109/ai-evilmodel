#!/bin/sh
# Native Labtainers hook; runs only in the separate instructor grader.
exec python3 -I "$(dirname "$0")/verify.py" "$1" "$2"
