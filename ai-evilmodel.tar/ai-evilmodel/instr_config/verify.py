#!/usr/bin/env python3
"""Independent artifact verification using Python's standard library only.

Never import or execute student programs. NPZ/NPY is parsed as bounded numeric
data without pickle, eval, NumPy or additional grader image dependencies.
Instructor reference files are copied by native gradelab into its own container.
"""
import ast
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import struct
import sys
import zipfile

SHAPES = {'fc1.weight': (512,784), 'fc1.bias': (512,),
          'fc2.weight': (256,512), 'fc2.bias': (256,),
          'fc3.weight': (10,256), 'fc3.bias': (10,)}
REFDIR = Path(__file__).resolve().parent

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read(path, limit=3*1024*1024):
    require(not any(p.is_symlink() for p in [path]+list(path.parents)), 'symlink evidence')
    require(path.is_file() and path.stat().st_size <= limit, 'missing/oversized '+path.name)
    return path.read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def npz(raw, shapes, dtype):
    result = {}
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(sorted(z.namelist()) == sorted(k+'.npy' for k in shapes), 'NPZ tensor names')
        require(sum(i.file_size for i in z.infolist()) < 3*1024*1024, 'NPZ expansion limit')
        for key, shape in shapes.items():
            buf = z.read(key+'.npy')
            require(buf[:8] == b'\x93NUMPY\x01\x00', 'NPY version must be 1.0')
            n = struct.unpack('<H', buf[8:10])[0]
            require(n < 4096, 'NPY header limit')
            header = ast.literal_eval(buf[10:10+n].decode('latin1').strip())
            require(header == dict(descr=dtype, fortran_order=False, shape=shape), 'NPY shape/dtype/order: '+key)
            data = buf[10+n:]
            count = 1
            for dim in shape: count *= dim
            require(len(data) == count*(4 if dtype == '<f4' else 1), 'NPY data length')
            if dtype == '<f4':
                require(all(math.isfinite(v[0]) for v in struct.iter_unpack('<f',data)), 'nonfinite weights')
            result[key] = data
    return result

def synthetic(raw):
    require(len(raw) == 262144, 'payload must be 256 KiB')
    sid = raw[12:44].rstrip(b'\0')
    require(re.fullmatch(rb'[A-Za-z0-9_-]{1,32}',sid) is not None and sid != b'YOUR_STUDENT_ID', 'student ID')
    header = b'AIEMDATA'+struct.pack('<I',262144)+sid.ljust(32,b'\0')+bytes(20)
    expected = header+hashlib.shake_256(b'ai-evilmodel/harmless/v1/'+sid).digest(262144-64)
    require(raw == expected, 'invalid synthetic training data')
    return raw

def predict(model, images):
    # Independent scalar implementation, double accumulation. Argmax verified
    # against Float32 on the packaged dataset and all workflow test fixtures.
    layers = []
    for i in range(1,4):
        shape = SHAPES['fc%d.weight'%i]
        flat = [v[0] for v in struct.iter_unpack('<f',model['fc%d.weight'%i])]
        rows = [flat[j*shape[1]:(j+1)*shape[1]] for j in range(shape[0])]
        biases = [v[0] for v in struct.iter_unpack('<f',model['fc%d.bias'%i])]
        layers.append((rows,biases))
    predictions = []
    for offset in range(0,len(images),784):
        x = [v/255.0 for v in images[offset:offset+784]]
        for i,(rows,biases) in enumerate(layers):
            x = [sum(w*v for w,v in zip(row,x))+b for row,b in zip(rows,biases)]
            if i<2: x = [max(0,v) for v in x]
        require(all(math.isfinite(v) for v in x), 'nonfinite inference')
        predictions.append(max(range(10),key=x.__getitem__))
    return predictions

def grade(base):
    # The native grader derives this directory from the submission's inner ZIP
    # name. Bind it to the native .email and .seed, then to the payload ID.
    suffix = '.ai-evilmodel'
    require(base.parent.name.endswith(suffix), 'unexpected submission lab name')
    student_id = base.parent.name[:-len(suffix)]
    require(re.fullmatch(r'[A-Za-z0-9_-]{1,32}', student_id) is not None, 'invalid submission student ID')
    require(read(base/'.local/.email',128).decode('ascii').strip() == student_id,
            'submission identity does not match native .email')
    require(read(base/'.local/.labname',128).decode('ascii').strip() == 'ai-evilmodel',
            'native lab identity mismatch')
    # ParseStartConfig.finalize prefixes LAB_MASTER_SEED with the lab name.
    expected_seed = hashlib.md5(('ai-evilmodelai_evilmodel_fixed_2026:'+student_id).encode('ascii')).hexdigest()
    require(read(base/'.local/.seed',128).decode('ascii').strip() == expected_seed,
            'native seed does not match student ID')
    ref = json.loads((REFDIR/'reference.json').read_text())
    cleanraw = (REFDIR/'model_clean.npz').read_bytes()
    testraw = (REFDIR/'mnist_test.npz').read_bytes()
    require(sha(cleanraw) == ref['model_sha256'] and sha(testraw) == ref['test_sha256'], 'instructor reference integrity')
    canonical = npz(cleanraw,SHAPES,'<f4')
    test = npz(testraw,dict(images=(100,28,28),labels=(100,)),'|u1')
    labels = list(test['labels'])
    root = base/'ai-evilmodel'
    results = root/'results'
    scores = [0]*4
    feedback = []

    def check(task, points, name, fn):
        try:
            fn()
            scores[task-1] += points
            feedback.append('PASS +{} task{} {}'.format(points,task,name))
        except Exception as e:
            feedback.append('FAIL task{} {}: {}'.format(task,name,e))

    def clean_ok():
        raw = read(root/'samples/model_clean.npz')
        require(sha(raw) == ref['model_sha256'], 'original model changed')
        npz(raw,SHAPES,'<f4')
    def test_ok():
        require(read(root/'samples/mnist_test.npz') == testraw, 'fixed 100 MNIST images changed or missing')
    def embedded():
        raw = read(results/'model_embedded.npz')
        return raw,npz(raw,SHAPES,'<f4')
    def payload():
        raw = synthetic(read(results/'payload.bin'))
        require(raw[12:44].rstrip(b'\0').decode('ascii') == student_id,
                'payload STUDENT_ID must match the ID entered at lab startup')
        return raw
    def stored():
        original = payload()
        _, model = embedded()
        for name in SHAPES:
            a,b = canonical[name],model[name]
            if name != 'fc1.weight':
                require(a == b, 'unexpected modification: '+name)
            else:
                require(b[0:len(original)*4:4] == original, 'payload not stored in low bits')
                require(b[len(original)*4:] == a[len(original)*4:], 'unused weights changed')
                require(all(a[j:j+3] == b[j:j+3] for j in range(1,len(original)*4,4)), 'upper 24 bits changed')
    def evaluation(filename, raw, predictions):
        value = json.loads(read(results/filename,20000).decode('utf-8'))
        correct = sum(a==b for a,b in zip(predictions,labels))
        require(type(value.get('num_samples')) is int and value['num_samples'] == 100, 'sample count')
        require(value.get('model_sha256') == sha(raw), 'model hash')
        require(value.get('test_sha256') == ref['test_sha256'], 'test hash')
        for key in ('labels','predictions'):
            require(isinstance(value.get(key),list) and len(value[key]) == 100 and
                    all(type(v) is int and 0 <= v <= 9 for v in value[key]), 'invalid class IDs')
        require(value.get('labels') == labels and value.get('predictions') == predictions, 'independent predictions/labels mismatch')
        require(type(value.get('correct')) is int and value['correct'] == correct, 'correct count')
        require(type(value.get('accuracy')) in (int,float) and math.isfinite(value['accuracy']) and value['accuracy'] == correct/100, 'accuracy')
        return value
    check(1,5,'clean model',clean_ok)
    check(1,5,'fixed test set',test_ok)
    check(1,10,'clean evaluation',lambda: evaluation('eval_clean.json',cleanraw,ref['predictions']))
    check(2,10,'synthetic payload',payload)
    check(2,5,'embedded structure',embedded)
    check(2,10,'low-bit embedding',stored)
    def report_ok():
        raw,_ = embedded()
        entries = dict(line.split('=',1) for line in read(results/'embed_report.txt',2000).decode('ascii').splitlines())
        require(entries == dict(layer='fc1.weight',bytes='262144',weights_used='262144',
                                payload_sha256=sha(payload()),model_sha256=sha(raw)), 'report disagrees with artifacts')
    check(2,5,'embedding report',report_ok)
    predictions = None
    embeddedraw = None
    try:
        embeddedraw, model = embedded()
        predictions = predict(model,test['images'])
    except Exception as e:
        feedback.append('Embedded inference unavailable: '+str(e))
    def evaluations_ok():
        require(predictions is not None, 'invalid embedded model')
        a = evaluation('eval_clean.json',cleanraw,ref['predictions'])
        b = evaluation('eval_embedded.json',embeddedraw,predictions)
        return a,b
    check(3,10,'embedded evaluation',lambda: evaluation('eval_embedded.json',embeddedraw,predictions) if predictions is not None else require(False,'invalid embedded model'))
    def same_test():
        test_ok()
        evaluations_ok()
    check(3,5,'same test images',same_test)
    def comparison_ok():
        a,b = evaluations_ok()
        comparison = json.loads(read(results/'comparison.json',2000).decode('utf-8'))
        expected = dict(test_sha256=ref['test_sha256'],accuracy_clean=a['accuracy'],
                        accuracy_embedded=b['accuracy'],accuracy_delta=b['accuracy']-a['accuracy'],
                        changed_predictions=sum(x!=y for x,y in zip(ref['predictions'],predictions)))
        require(comparison == expected, 'comparison calculation mismatch')
    check(3,10,'comparison',comparison_ok)
    def recovered_size():
        require(len(read(results/'recovered.bin')) == 262144, 'recovered must be 256 KiB')
    check(4,5,'recovered size',recovered_size)
    def recovered_hash():
        stored()
        require(sha(read(results/'recovered.bin')) == sha(payload()), 'recovered SHA-256 mismatch')
    check(4,10,'recovered hash',recovered_hash)
    def recovered_bytes():
        stored()
        raw = read(results/'recovered.bin')
        require(raw == payload() == embedded()[1]['fc1.weight'][0:262144*4:4], 'recovered bytes mismatch')
    check(4,10,'byte equality with embedded data',recovered_bytes)
    return scores,feedback

def main():
    base = Path(sys.argv[1])/sys.argv[2]
    out = base/'.local/result/ai-evilmodel-grade'
    # Remove student-supplied points unconditionally before writing fresh results.
    if out.is_symlink() or out.is_file(): out.unlink()
    elif out.exists(): shutil.rmtree(str(out))
    out.mkdir(parents=True,exist_ok=True)
    try:
        scores,feedback = grade(base)
    except Exception as e:
        scores,feedback = [0]*4,['Grading failed closed: '+str(e)]
    for name,points in list(zip(['task1','task2','task3','task4'],scores))+[('total',sum(scores))]:
        (out/(name+'.txt')).write_text('verified\n'*points)
    (out/'feedback.txt').write_text('\n'.join(feedback)+'\n')
    print('ai-evilmodel: {} / 100; tasks {}'.format(sum(scores),scores))

if __name__ == '__main__':
    main()
